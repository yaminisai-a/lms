package com.example.lmsbackend.controller;

import com.example.lmsbackend.model.Customer;
import com.example.lmsbackend.model.Loan;
import com.example.lmsbackend.repository.CustomerRepository;
import com.example.lmsbackend.repository.LoanRepository;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.core.Authentication;

import java.util.List;

@RestController
@RequestMapping("/api/loans")
@CrossOrigin(origins = "*")
public class LoanController {

    private final LoanRepository loanRepository;
    private final CustomerRepository customerRepository;

    public LoanController(LoanRepository loanRepository,
                          CustomerRepository customerRepository) {
        this.loanRepository = loanRepository;
        this.customerRepository = customerRepository;
    }

    // ================= GET LOANS =================
    @GetMapping
    public List<Loan> getLoans(Authentication auth) {

        boolean isAdmin = auth.getAuthorities()
                .stream()
                .anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"));

        if (isAdmin) {
            return loanRepository.findAll();
        }

        return loanRepository
                .findByCustomerUserUsername(auth.getName());
    }

    // ================= GET BY ID =================
    @GetMapping("/{id}")
    public ResponseEntity<?> getById(@PathVariable Long id,
                                     Authentication auth) {

        return loanRepository.findById(id)
                .map(loan -> {

                    boolean isAdmin = auth.getAuthorities()
                            .stream()
                            .anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"));

                    if (isAdmin) {
                        return ResponseEntity.ok(loan);
                    }

                    if (loan.getCustomer()
                            .getUser()
                            .getUsername()
                            .equals(auth.getName())) {

                        return ResponseEntity.ok(loan);
                    }

                    return ResponseEntity.status(403).build();
                })
                .orElse(ResponseEntity.notFound().build());
    }

    // ================= CREATE =================
    @PostMapping
    public ResponseEntity<Loan> create(@RequestBody Loan loan,
                                       Authentication auth) {

        boolean isAdmin = auth.getAuthorities()
                .stream()
                .anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"));

        Customer customer;

        if (isAdmin) {
            customer = customerRepository
                    .findById(loan.getCustomer().getId())
                    .orElseThrow(() ->
                            new IllegalArgumentException("Customer not found"));
        } else {
            customer = customerRepository
                    .findByUserUsername(auth.getName())
                    .orElseThrow(() ->
                            new IllegalArgumentException("Customer not found"));
        }

        loan.setCustomer(customer);

        return ResponseEntity.ok(
                loanRepository.save(loan)
        );
    }

    // ================= UPDATE =================
    @PutMapping("/{id}")
    public ResponseEntity<?> update(@PathVariable Long id,
                                     @RequestBody Loan updated,
                                     Authentication auth) {

        return loanRepository.findById(id)
                .map(existing -> {

                    boolean isAdmin = auth.getAuthorities()
                            .stream()
                            .anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"));

                    if (!isAdmin) {
                        return ResponseEntity.status(403).build();
                    }

                    Customer customer = customerRepository
                            .findById(updated.getCustomer().getId())
                            .orElseThrow(() ->
                                    new IllegalArgumentException("Customer not found"));

                    existing.setCustomer(customer);
                    existing.setPrincipalAmount(updated.getPrincipalAmount());
                    existing.setInterestRate(updated.getInterestRate());
                    existing.setTermMonths(updated.getTermMonths());
                    existing.setStartDate(updated.getStartDate());
                    existing.setEndDate(updated.getEndDate());
                    existing.setStatus(updated.getStatus());

                    return ResponseEntity.ok(
                            loanRepository.save(existing)
                    );
                })
                .orElse(ResponseEntity.notFound().build());
    }

    // ================= DELETE =================
    @DeleteMapping("/{id}")
    public ResponseEntity<Object> delete(@PathVariable Long id,
                                       Authentication auth) {

        return loanRepository.findById(id)
                .map(loan -> {

                    boolean isAdmin = auth.getAuthorities()
                            .stream()
                            .anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"));

                    if (!isAdmin) {
                        return ResponseEntity.status(403).build();
                    }

                    loanRepository.delete(loan);

                    return ResponseEntity.noContent().build();
                })
                .orElse(ResponseEntity.notFound().build());
    }
}
