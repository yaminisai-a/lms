package com.example.lmsbackend.controller;

import com.example.lmsbackend.model.Customer;
import com.example.lmsbackend.model.Loan;
import com.example.lmsbackend.repository.CustomerRepository;
import com.example.lmsbackend.repository.LoanRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/loans")
@CrossOrigin(origins = "*")
public class LoanController {

    private final LoanRepository loanRepository;
    private final CustomerRepository customerRepository;

    public LoanController(LoanRepository loanRepository, CustomerRepository customerRepository) {
        this.loanRepository = loanRepository;
        this.customerRepository = customerRepository;
    }

    @GetMapping
    public List<Loan> getAll() {
        return loanRepository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Loan> getById(@PathVariable Long id) {
        return loanRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<Loan> create(@RequestParam Long customerId, @RequestBody Loan loan) {
        Customer customer = customerRepository.findById(customerId)
                .orElseThrow(() -> new IllegalArgumentException("Customer not found"));
        loan.setCustomer(customer);
        return ResponseEntity.ok(loanRepository.save(loan));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Loan> update(@PathVariable Long id,
                                       @RequestParam Long customerId,
                                       @RequestBody Loan updated) {
        return loanRepository.findById(id)
                .map(existing -> {
                    Customer customer = customerRepository.findById(customerId)
                            .orElseThrow(() -> new IllegalArgumentException("Customer not found"));
                    existing.setCustomer(customer);
                    existing.setPrincipalAmount(updated.getPrincipalAmount());
                    existing.setInterestRate(updated.getInterestRate());
                    existing.setTermMonths(updated.getTermMonths());
                    existing.setStartDate(updated.getStartDate());
                    existing.setEndDate(updated.getEndDate());
                    existing.setStatus(updated.getStatus());
                    return ResponseEntity.ok(loanRepository.save(existing));
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        if (!loanRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        loanRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}

