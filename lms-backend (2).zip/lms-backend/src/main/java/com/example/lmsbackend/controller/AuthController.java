package com.example.lmsbackend.controller;

import com.example.lmsbackend.dto.AuthRequest;
import com.example.lmsbackend.dto.AuthResponse;
import com.example.lmsbackend.model.Role;
import com.example.lmsbackend.model.User;
import com.example.lmsbackend.repository.RoleRepository;
import com.example.lmsbackend.repository.UserRepository;
import com.example.lmsbackend.security.JwtService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.Collections;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "*")
public class AuthController {

    private final AuthenticationManager authenticationManager;
    private final JwtService jwtService;
    private final UserRepository userRepository;
    private final RoleRepository roleRepository;
    private final PasswordEncoder passwordEncoder;

    public AuthController(AuthenticationManager authenticationManager,
                          JwtService jwtService,
                          UserRepository userRepository,
                          RoleRepository roleRepository,
                          PasswordEncoder passwordEncoder) {
        this.authenticationManager = authenticationManager;
        this.jwtService = jwtService;
        this.userRepository = userRepository;
        this.roleRepository = roleRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @PostMapping("/login")
    public ResponseEntity<AuthResponse> login(@RequestBody AuthRequest request) {

        Authentication authentication = authenticationManager.authenticate(
            new UsernamePasswordAuthenticationToken(
                request.getUsername(),
                request.getPassword()
            )
        );

        SecurityContextHolder.getContext().setAuthentication(authentication);

        var springUser =
            (org.springframework.security.core.userdetails.User) authentication.getPrincipal();

        String actualRole = springUser.getAuthorities()
            .stream()
            .findFirst()
            .map(a -> a.getAuthority())   // ROLE_USER / ROLE_ADMIN
            .orElse("");

        String requestedRole = request.getRole();

        // ✅ FIX: correct UI → DB role mapping
        if ("Customer".equalsIgnoreCase(requestedRole)) {
            requestedRole = "ROLE_USER";
        } else if ("Admin".equalsIgnoreCase(requestedRole)) {
            requestedRole = "ROLE_ADMIN";
        }

        if (!actualRole.equals(requestedRole)) {
            return ResponseEntity.status(403).build();
        }

        String token = jwtService.generateToken(springUser);
        return ResponseEntity.ok(new AuthResponse(token, actualRole));
    }


    @PostMapping("/register")
    public ResponseEntity<String> register(@RequestBody AuthRequest request) {
        if (userRepository.existsByUsername(request.getUsername())) {
            return ResponseEntity.badRequest().body("Username already taken");
        }

        Role userRole = roleRepository.findByName("ROLE_USER")
                .orElseGet(() -> roleRepository.save(new Role(null, "ROLE_USER")));

        User user = new User();
        user.setUsername(request.getUsername());
        user.setPassword(passwordEncoder.encode(request.getPassword()));
        user.setRoles(Collections.singleton(userRole));

        userRepository.save(user);
        return ResponseEntity.ok("User registered successfully");
    }
}

