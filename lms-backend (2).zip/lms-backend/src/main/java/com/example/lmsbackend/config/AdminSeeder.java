package com.example.lmsbackend.config;

import com.example.lmsbackend.model.Role;
import com.example.lmsbackend.model.User;
import com.example.lmsbackend.repository.RoleRepository;
import com.example.lmsbackend.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.Set;

@Configuration
public class AdminSeeder implements CommandLineRunner {

    private final UserRepository userRepo;
    private final RoleRepository roleRepo;
    private final PasswordEncoder encoder;

    public AdminSeeder(UserRepository userRepo,
                       RoleRepository roleRepo,
                       PasswordEncoder encoder) {
        this.userRepo = userRepo;
        this.roleRepo = roleRepo;
        this.encoder = encoder;
    }

    @Override
    public void run(String... args) {

        Role adminRole = roleRepo.findByName("ROLE_ADMIN")
                .orElseGet(() -> roleRepo.save(new Role(null, "ROLE_ADMIN")));

        roleRepo.findByName("ROLE_USER")
                .orElseGet(() -> roleRepo.save(new Role(null, "ROLE_USER")));

        if (!userRepo.existsByUsername("admin@lms.com")) {
            User admin = new User();
            admin.setUsername("admin@lms.com");
            admin.setPassword(encoder.encode("Admin@123"));
            admin.setRoles(Set.of(adminRole));
            userRepo.save(admin);

            System.out.println("✅ DEFAULT ADMIN CREATED");
        }
    }
}
