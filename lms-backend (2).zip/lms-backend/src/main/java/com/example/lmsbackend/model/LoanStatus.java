package com.example.lmsbackend.model;

public enum LoanStatus {
    ACTIVE,
    CLOSED,
    PENDING
}

