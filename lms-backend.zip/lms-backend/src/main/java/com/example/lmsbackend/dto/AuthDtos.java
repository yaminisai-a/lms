package com.example.lmsbackend.dto;

import lombok.Data;

@Data
public class AuthRequest {
    private String username;
    private String password;
}

@Data
class AuthResponse {
    private final String token;
}

