package com.example.lmsbackend.repository;

import java.util.Optional;

import com.example.lmsbackend.model.Customer;

import org.springframework.data.jpa.repository.JpaRepository;

public interface CustomerRepository extends JpaRepository<Customer, Long> {
Optional<Customer> findByUserUsername(String username);
}

