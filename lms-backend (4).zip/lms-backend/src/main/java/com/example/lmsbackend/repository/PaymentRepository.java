package com.example.lmsbackend.repository;

import com.example.lmsbackend.model.Payment;
import com.example.lmsbackend.model.Loan;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface PaymentRepository extends JpaRepository<Payment, Long> {

    // Get payments by list of loans
    List<Payment> findByLoanIn(List<Loan> loans);
}
