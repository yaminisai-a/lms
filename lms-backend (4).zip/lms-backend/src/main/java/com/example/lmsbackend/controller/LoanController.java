package com.example.lmsbackend.controller;

import com.example.lmsbackend.model.Customer;
import com.example.lmsbackend.model.Loan;
import com.example.lmsbackend.repository.CustomerRepository;
import com.example.lmsbackend.repository.LoanRepository;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.core.Authentication;

import java.util.List;

@RestController
@RequestMapping("/api/loans")
@CrossOrigin(origins = "*")
public class LoanController {

    private final LoanRepository loanRepository;
    private final CustomerRepository customerRepository;

    public LoanController(LoanRepository loanRepository,
                          CustomerRepository customerRepository) {
        this.loanRepository = loanRepository;
        this.customerRepository = customerRepository;
    }

    // ================= GET LOANS =================
    @GetMapping
    public List<Loan> getLoans(Authentication auth) {

        boolean isAdmin = auth.getAuthorities()
                .stream()
                .anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"));

        if (isAdmin) {
            return loanRepository.findAll();
        }

        return loanRepository
                .findByCustomerUserUsername(auth.getName());
    }

    // ================= CREATE =================
    @PostMapping
    public ResponseEntity<?> create(@RequestBody Loan loan,
                                    Authentication auth) {

        try {

            Customer customer = customerRepository
                    .findById(loan.getCustomer().getId())
                    .orElseThrow(() -> new RuntimeException("Customer not found"));

            Loan newLoan = new Loan();
            newLoan.setCustomer(customer);
            newLoan.setPrincipalAmount(loan.getPrincipalAmount());
            newLoan.setInterestRate(loan.getInterestRate());
            newLoan.setTermMonths(loan.getTermMonths());
            newLoan.setStartDate(loan.getStartDate());
            newLoan.setStatus(loan.getStatus()); // ✅ IMPORTANT

            Loan saved = loanRepository.save(newLoan);

            return ResponseEntity.ok(saved);

        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    // ================= DELETE =================
    @DeleteMapping("/{id}")
    public ResponseEntity<?> delete(@PathVariable Long id,
                                    Authentication auth) {

        return loanRepository.findById(id)
                .map(loan -> {

                    boolean isAdmin = auth.getAuthorities()
                            .stream()
                            .anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"));

                    if (!isAdmin) {
                        return ResponseEntity.status(403).build();
                    }

                    loanRepository.delete(loan);
                    return ResponseEntity.noContent().build();
                })
                .orElse(ResponseEntity.notFound().build());
    }
}
