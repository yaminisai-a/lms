package com.example.lmsbackend.controller;

import com.example.lmsbackend.model.Loan;
import com.example.lmsbackend.model.Payment;
import com.example.lmsbackend.repository.LoanRepository;
import com.example.lmsbackend.repository.PaymentRepository;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.core.Authentication;

import java.util.List;

@RestController
@RequestMapping("/api/payments")
@CrossOrigin(origins = "*")
public class PaymentController {

    private final PaymentRepository paymentRepository;
    private final LoanRepository loanRepository;

    public PaymentController(PaymentRepository paymentRepository,
                             LoanRepository loanRepository) {
        this.paymentRepository = paymentRepository;
        this.loanRepository = loanRepository;
    }

    // ================= GET PAYMENTS =================
    @GetMapping
    public List<Payment> getPayments(Authentication auth) {

        boolean isAdmin = auth.getAuthorities()
                .stream()
                .anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"));

        // ADMIN → return all payments
        if (isAdmin) {
            return paymentRepository.findAll();
        }

        // CUSTOMER → only his payments
        List<Loan> userLoans =
                loanRepository.findByCustomerUserUsername(auth.getName());

        return paymentRepository.findByLoanIn(userLoans);
    }

    // ================= GET BY ID =================
    @GetMapping("/{id}")
    public ResponseEntity<Payment> getById(@PathVariable Long id,
                                           Authentication auth) {

        return (ResponseEntity<Payment>) paymentRepository.findById(id)
                .map(payment -> {

                    boolean isAdmin = auth.getAuthorities()
                            .stream()
                            .anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"));

                    if (isAdmin) {
                        return ResponseEntity.ok(payment);
                    }

                    if (payment.getLoan()
                            .getCustomer()
                            .getUser()
                            .getUsername()
                            .equals(auth.getName())) {

                        return ResponseEntity.ok(payment);
                    }

                    return ResponseEntity.status(403).build();
                })
                .orElse(ResponseEntity.notFound().build());
    }

    // ================= CREATE PAYMENT =================
    @PostMapping
    public ResponseEntity<Payment> create(@RequestBody Payment payment,
                                          Authentication auth) {

        Loan loan = loanRepository.findById(
                payment.getLoan().getId())
                .orElseThrow(() ->
                        new IllegalArgumentException("Loan not found"));

        boolean isAdmin = auth.getAuthorities()
                .stream()
                .anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"));

        // CUSTOMER → can only create for own loan
        if (!isAdmin &&
            !loan.getCustomer()
                 .getUser()
                 .getUsername()
                 .equals(auth.getName())) {

            return ResponseEntity.status(403).build();
        }

        payment.setLoan(loan);

        Payment saved = paymentRepository.save(payment);

        return ResponseEntity.ok(saved);
    }

    // ================= DELETE PAYMENT =================
    @DeleteMapping("/{id}")
    public ResponseEntity<Object> delete(@PathVariable Long id,
                                       Authentication auth) {

        return paymentRepository.findById(id)
                .map(payment -> {

                    boolean isAdmin = auth.getAuthorities()
                            .stream()
                            .anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"));

                    if (!isAdmin &&
                        !payment.getLoan()
                                .getCustomer()
                                .getUser()
                                .getUsername()
                                .equals(auth.getName())) {

                        return ResponseEntity.status(403).build();
                    }

                    paymentRepository.delete(payment);

                    return ResponseEntity.noContent().build();
                })
                .orElse(ResponseEntity.notFound().build());
    }
}
